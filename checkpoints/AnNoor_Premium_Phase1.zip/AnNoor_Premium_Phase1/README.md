# An-Noor International Online Madrasa — Reconstructed Website

## Files
- `index.html`: complete reconstructed HTML page
- `assets/css/style.css`: full original CSS extracted without changes
- `assets/js/app.js`: full original application JavaScript extracted without changes
- `original-backup/index.backup-phase1.html`: preserved original Qwen backup

## How to run
Open `index.html` in Chrome or Edge. For reliable local testing, run a local static server in this folder:

```bash
python -m http.server 8000
```

Then open http://localhost:8000. Do not open only `index.html` outside the folder: it requires the `assets` directory.

## Important
- This is a faithful recovery and modularization of the most complete backup in the supplied Qwen archive, not a new LMS.
- Existing admission and review submission flows are demonstrations and do not save data to a backend.
- There is no live payment gateway, student authentication, or production database.
- External Google Fonts require an internet connection.
- Full visual and interactive browser QA remains necessary before deployment.
- The original source HTML supplied separately was retained for comparison; this package follows the more recent Qwen backup to preserve its edits.
