# An-Noor International Online Madrasa — Phase 2.1

Continuation of the supplied Phase 1 project, not a replacement template.

## Open
Extract the complete ZIP. Open `index.html` in Chrome or Edge. Keep `assets/` beside it. Alternatively, from this directory run `python -m http.server 8000` and visit `http://localhost:8000`.

## Delivered
Responsive header and mobile menu; keyboard-operable Explore disclosure; language and persistent light/dark controls; active section links; refined original green/gold homepage, teacher cards, plan comparison, reviews and footer; honest Courses and Student Login entry pages. Existing admission demo, teacher profiles, local audio previews and time zone clocks retained.

## Source map
- `index.html`: bilingual markup, four views, metadata and existing JSON-LD.
- `assets/css/style.css`: retained Phase 1 stylesheet.
- `assets/css/phase2.css`: documented Phase 2 refinements.
- `assets/js/app.js`: original content/rendering, audio, admission, reviews, clocks, routing.
- `assets/js/preferences.js`: safe early display preference initialization.
- `assets/js/navigation.js`: mobile/disclosure controls, active links and theme switch.
- `assets/images/`: four original WebP assets, byte-for-byte preserved.
- `checkpoints/AnNoor_Premium_Phase1.zip`: exact uploaded Phase 1 checkpoint.
- `original-backup/`: original recovered monolithic backup; not the current site.
- `tests/`: runnable offline regression checks.

## Verification
Run `python tests/verify.py` and `node tests/logic.cjs`. See TEST_RESULTS.md for observed results and untested browser behavior.

## Status
This is a public-site prototype, not a production LMS. Applications and reviews are not saved or sent. Teacher details and policies require approval. No authentication, payments, protected media, database, enrollment or course marketplace is implemented. Login and Courses explicitly state availability rather than simulate these services. Google Fonts require internet; local fallback fonts remain available. Source is packaged for review; this ZIP does not deploy a hosted site.

See DEVELOPMENT_ROADMAP.md for subsequent phases and required inputs. The supplied master prompt ends mid-sentence after “Create database migrations and document”; no omitted requirements have been assumed.

Phase 2.1 restores the original breathing/glowing logo, 8%-opacity Quran typography backgrounds and animated live-clock orbit/indicator.
